# reconpy

Python recon orchestrator for bug bounty workflows. Wraps ffuf, amass, subfinder,
sublist3r, haktrails, dnsx, httpx, nmap, whatweb, webanalyze, wpscan, cmsmap,
dirsearch, gobuster, hakrawler, katana, gospider, gau, waybackurls, paramspider,
assetfinder, linkfinder, secretfinder, xnLinkFinder, urlfinder, mantra, karma_v2,
smap, kiterunner, arjun, qsreplace, oralyzer, openredirex, nuclei, uro, dalfox,
xsstrike, loxs, pwnxss, xspear, xssfinder, sqlmap, crlfuzz, commix, and smuggler
into one Python CLI, `reconpy`, installable once and runnable globally from any
directory.

## Install

Requires Python 3.8+. From inside the extracted project folder:

```bash
pip install --break-system-packages --no-build-isolation .
```

`--no-build-isolation` uses your already-installed `setuptools` instead of trying
to fetch one over the network, which fails in offline/restricted environments.

This creates a global `reconpy` command on your PATH (typically at
`~/.local/bin/reconpy` on Debian — make sure that's in your PATH:
`export PATH="$HOME/.local/bin:$PATH"` in `.bashrc` if it isn't already).

### Update after making changes to the source

```bash
pip install --break-system-packages --no-build-isolation --force-reinstall .
```

### Uninstall

```bash
pip uninstall reconpy
```

## Usage

Run it from any directory — output files land wherever you're standing:

```bash
cd ~/recon/chmedia
reconpy chmedia.ch
```

### Full pipeline with wordlists

```bash
reconpy chmedia.ch \
    --subs-wordlist /root/wordlist/shorts/subdomains.txt \
    --kite-wordlist /root/wordlist/large.kite \
    --dir-wordlist /root/wordlist/shorts/dir.txt \
    --xss-wordlist /root/wordlist/shorts/xss.txt
```

Missing/empty wordlists are silently skipped — that step just runs without one,
or is skipped entirely if it strictly requires one (e.g. `brutesubrecon` needs a
subdomains wordlist, `apirecon` needs a `.kite` file).

### Domain list instead of a single domain

```bash
reconpy domains.txt
```

### Run a single module

```bash
reconpy chmedia.ch -m passivesubrecon
reconpy chmedia.ch -m techrecon
reconpy chmedia.ch -m reconfilter
```

Full module list:

```
passivesubrecon  brutesubrecon  iprecon  techrecon  nmapscan
dirrecon  crawlrecon  urlrecon  findrecon  apirecon  hunter
reconfilter  xssrecon  sqlrecon  commixrecon  smugglerrecon
```

### Explicit output directory

```bash
reconpy chmedia.ch -o /root/recon/chmedia
```

## SecurityTrails / haktrails setup (optional)

No API key is hardcoded anywhere. To enable `haktrails` in `passivesubrecon`:

**Option A** — set an env var once; reconpy writes the config for you automatically:

```bash
export SECURITYTRAILS_API_KEY="your-key-here"
```

Add that line to `~/.bashrc` to persist it across sessions.

**Option B** — configure haktrails yourself, exactly as before:

```bash
mkdir -p ~/.config/haktrails
echo "securitytrails-key: your-key-here" > ~/.config/haktrails/config.yml
```

If neither is set, `passivesubrecon` skips the haktrails step and continues with
amass/subfinder/sublist3r.

## Module responsibilities (no tool redundancy)

Each external tool is called from exactly one place to keep runs fast on a
1-core/1GB VM:

- `dnsx` / `httpx` resolution — only in `iprecon`
- `linkfinder` / `secretfinder` / `assetfinder` — only in `findrecon` (link and
  secret discovery on live pages/JS via crawling, not raw file content)
- `paramspider` — only in `urlrecon`
- `crlfuzz` — only in `sqlrecon`
- `oralyzer` — only in `apirecon`
- **JS content download + secret scanning** — only in `reconfilter`, run *after*
  all URL-gathering modules finish. It downloads every URL that lands in `js.txt`
  and greps the actual file content for hardcoded secrets, separately from
  `findrecon`'s live crawling-based discovery.

`brutesubrecon`'s `ffuf` call is capped with `-maxtime 1800` (30 minutes per
domain) so a large wordlist can never hang indefinitely, and it prints an
estimated runtime before starting.

## reconfilter — URL cleanup, JS isolation, and secret scanning

`reconfilter` runs near the end of the pipeline (after all URL/JS gathering
modules, before the vulnerability scanners) and does, in order:

1. Extracts and cleans every URL/domain pattern out of `urls.txt`, stripping
   noise, status-code tags, and stray non-URL text
2. Deduplicates deeply with `uro` if installed
3. Splits results into:
   - `js.txt` — **every** JS URL, including ones with query parameters
   - `parameters.txt` — every URL with a `?` query string
   - `cleaned.txt` — everything left after removing JS/CSS/image/font/JSON URLs
4. Downloads the actual content of every URL in `js.txt` and scans it for
   hardcoded secrets (API keys, tokens, JWTs, AWS keys, Mongo URIs, etc.),
   writing matches to `Findings.txt` (broad pattern) and `jsecrets.txt`
   (stricter pattern with false-positive filtering)

Because this runs after `urlrecon`/`findrecon`/`apirecon`/`crawlrecon` have all
contributed to `urls.txt`, JS URLs that arrived from any tool end up correctly
isolated into `js.txt` and out of `cleaned.txt`, regardless of which upstream
tool originally found them.

## Output files

All files are flat text files in the output directory, no subdirectories:

```
subdomains.txt      activesubs.txt      subs.txt          cleanedsubs.txt
validsubs.txt       ips.txt             ipsv6.txt         urls.txt
curls.txt           findurls.txt        burl.txt          parameters.txt
js.txt              alljs.txt           cleaned.txt       jsecrets.txt
tech.txt            techstack.txt       vulnerable_urls.txt
report.txt          nmapreport.txt      network.txt
xssreport.txt       sqlreport.txt       cmdireport.txt    smugglerreport.txt
secretsreport.txt   karmareport.txt     Findings.txt
```
