import os
import re
import time
import shutil
import socket
import ipaddress
import subprocess

PRIVATE_RANGES = [
    ipaddress.ip_network("10.0.0.0/8"),
    ipaddress.ip_network("172.16.0.0/12"),
    ipaddress.ip_network("192.168.0.0/16"),
    ipaddress.ip_network("127.0.0.0/8"),
    ipaddress.ip_network("0.0.0.0/8"),
    ipaddress.ip_network("169.254.0.0/16"),
]


def log(msg):
    print(f"[*] {msg}", flush=True)


def ok(msg):
    print(f"[+] {msg}", flush=True)


def warn(msg):
    print(f"[-] {msg}", flush=True)


def tool_exists(name):
    return shutil.which(name) is not None


def run(cmd, timeout=None, input_text=None):
    try:
        result = subprocess.run(
            cmd,
            shell=isinstance(cmd, str),
            capture_output=True,
            text=True,
            timeout=timeout,
            input=input_text,
        )
        return result.stdout or ""
    except subprocess.TimeoutExpired:
        return ""
    except FileNotFoundError:
        return ""
    except Exception:
        return ""


def read_lines(path):
    if not path or not os.path.isfile(path):
        return []
    with open(path, "r", errors="ignore") as f:
        return [line.strip() for line in f if line.strip()]


def write_lines(path, lines, append=True):
    mode = "a" if append else "w"
    with open(path, mode) as f:
        for line in lines:
            f.write(str(line) + "\n")


def dedup_file(path):
    if not os.path.isfile(path):
        return
    lines = read_lines(path)
    unique = sorted(set(lines))
    write_lines(path, unique, append=False)


def append_unique(path, new_lines):
    existing = set(read_lines(path))
    new_lines = set(x for x in new_lines if x)
    to_add = new_lines - existing
    if to_add:
        write_lines(path, sorted(to_add), append=True)
    return len(to_add)


def file_has_content(path):
    return path and os.path.isfile(path) and os.path.getsize(path) > 0


def wordlist_or_none(path):
    if path and os.path.isfile(path) and os.path.getsize(path) > 0:
        return path
    return None


def load_targets(input_value):
    targets = []
    if input_value and os.path.isfile(input_value):
        targets = read_lines(input_value)
    elif input_value:
        targets = [input_value]
    return sorted(set(targets))


def to_url(host):
    host = host.strip()
    if host.startswith("http://") or host.startswith("https://"):
        return host
    return f"https://{host}"


def strip_scheme(url):
    return url.replace("https://", "").replace("http://", "").rstrip("/")


def domain_of(url):
    return strip_scheme(url).split("/")[0]


def is_private_ip(ip_str):
    try:
        ip = ipaddress.ip_address(ip_str)
        return any(ip in net for net in PRIVATE_RANGES)
    except ValueError:
        return True


def resolve_socket(host):
    ips = []
    try:
        ips.append(socket.gethostbyname(host))
    except socket.gaierror:
        try:
            results = socket.getaddrinfo(host, None)
            for r in results:
                ip = r[4][0]
                if ":" not in ip:
                    ips.append(ip)
        except socket.gaierror:
            pass
    return ips


def sleep_for(seconds):
    time.sleep(seconds)


def belongs_to_domain(host, domains):
    for d in domains:
        if host == d or host.endswith("." + d):
            return True
    return False


class OutputFiles:
    def __init__(self, base_dir):
        self.base_dir = base_dir
        os.makedirs(base_dir, exist_ok=True)

    def path(self, name):
        from reconpy.core.config import OUTPUT_FILES
        filename = OUTPUT_FILES.get(name, name)
        return os.path.join(self.base_dir, filename)

    def touch(self, *names):
        for name in names:
            p = self.path(name)
            if not os.path.isfile(p):
                open(p, "a").close()
