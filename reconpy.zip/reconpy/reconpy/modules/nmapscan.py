import re
import json
import tempfile
import os
from datetime import datetime
from reconpy.core.utils import log, ok, warn, tool_exists, run, read_lines

VULN_KEYWORDS = [
    "VULNERABLE", "CVE-", "State: VULNERABLE", "State: LIKELY VULNERABLE",
    "exploitable", "Exploit", "exploit", "Risk factor", "HIGH", "CRITICAL",
    "disclosure", "injection", "overflow", "bypass", "traversal", "RCE",
    "remote code", "XSS", "SQL", "SSRF", "LFI", "RFI", "open redirect",
    "misconfiguration", "weak", "brute", "default credentials", "anonymous",
    "cleartext", "unencrypted", "backdoor",
]

RISKY = {
    "ftp": "Anonymous FTP access or credential sniffing risk",
    "telnet": "Cleartext credentials, should not be exposed",
    "snmp": "Information disclosure of OS/hardware/network details",
    "smb": "Check for EternalBlue / SMB relay exposure",
    "rdp": "Check for BlueKeep and brute-force exposure",
    "redis": "Often unauthenticated, can lead to RCE",
    "mongodb": "Often unauthenticated, full DB read/write risk",
    "elasticsearch": "Often unauthenticated, full data dump risk",
    "memcached": "Unauthenticated access, DDoS amplification risk",
    "docker": "Unauthenticated Docker API, full container takeover risk",
    "vnc": "Check for no-auth remote desktop access",
    "mysql": "Check for weak/default credentials",
    "postgresql": "Check for weak/default credentials",
    "http-proxy": "Open proxy misuse risk",
}

PORT_PATTERN = re.compile(r"^(\d+)/(tcp|udp)\s+(open)\s+(\S+)\s*(.*)$", re.MULTILINE)

NAABU_RATE = 200
NAABU_THREADS = 25
NAABU_TIMEOUT = 600


def naabu_discover_ports(ip):
    """
    Fast full-range SYN pre-scan using naabu. Returns a sorted list of
    open TCP port numbers as strings, or None if naabu is unavailable
    (caller should then fall back to nmap's own discovery).
    """
    if not tool_exists("naabu"):
        return None

    with tempfile.NamedTemporaryFile(suffix=".json", delete=False) as tmp:
        tmp_path = tmp.name

    run([
        "naabu", "-host", ip, "-p", "-",
        "-rate", str(NAABU_RATE), "-c", str(NAABU_THREADS),
        "-silent", "-json", "-o", tmp_path,
    ], timeout=NAABU_TIMEOUT)

    ports = []
    if os.path.isfile(tmp_path):
        with open(tmp_path, "r", errors="ignore") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    data = json.loads(line)
                    port = data.get("port")
                    if port:
                        ports.append(str(port))
                except (json.JSONDecodeError, ValueError):
                    continue
        os.remove(tmp_path)

    return sorted(set(ports), key=int)


def scan_ip(ip):
    ports = naabu_discover_ports(ip)

    if ports is None:
        warn(f"naabu not found, falling back to nmap's own full-range discovery for {ip} (slower).")
        return run([
            "timeout", "2700", "nmap", "-sV", "-sC", "--script", "vuln",
            "-p-", "-T3", "-n",
            "--min-rate", "100", "--max-rate", "300", "--max-retries", "2",
            "--host-timeout", "25m", "--script-timeout", "90s", "--stats-every", "60s",
            ip,
        ], timeout=2760)

    if not ports:
        ok(f"naabu found no open ports on {ip}, skipping nmap entirely.")
        return ""

    ok(f"naabu found {len(ports)} open port(s) on {ip}: {','.join(ports)}")
    port_list = ",".join(ports)

    return run([
        "timeout", "1200", "nmap", "-sV", "-sC", "--script", "vuln",
        "-p", port_list, "-T3", "-n",
        "--max-retries", "2",
        "--host-timeout", "15m", "--script-timeout", "90s",
        ip,
    ], timeout=1260)


def filter_vuln_output(content):
    blocks = re.split(r"\n(?=\d+/)", content)
    findings = []
    for block in blocks:
        block_lower = block.lower()
        matched = [kw for kw in VULN_KEYWORDS if kw.lower() in block_lower]
        if matched:
            findings.append(block.strip())
            findings.append(f"[!] Triggered keywords: {', '.join(set(matched))}")
            findings.append("-" * 64)

    script_sections = re.findall(r"(\|\s*\w[\w\-]+:.*?)(?=\n\d+/|\Z)", content, re.DOTALL)
    for section in script_sections:
        matched = [kw for kw in VULN_KEYWORDS if kw.lower() in section.lower()]
        if matched:
            findings.append(section.strip())
            findings.append(f"[!] Triggered keywords: {', '.join(set(matched))}")
            findings.append("-" * 64)

    return findings


def build_network_summary(content, target):
    lines = []
    lines.append("=" * 64)
    lines.append(f"NETWORK SUMMARY FOR: {target}")
    lines.append(f"Date: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    lines.append("=" * 64)
    lines.append("")

    open_ports = []
    for m in PORT_PATTERN.finditer(content):
        port, proto, state, service, version = m.groups()
        open_ports.append((port, proto, service.strip(), version.strip()))

    lines.append("OPEN PORTS")
    lines.append("-" * 10)
    if open_ports:
        for port, proto, service, version in open_ports:
            line = f"{port}/{proto}  {service}"
            if version:
                line += f"  {version}"
            lines.append(line)
    else:
        lines.append("No open ports found.")
    lines.append("")

    lines.append("POTENTIAL THREATS")
    lines.append("-" * 17)
    threat_found = False
    for port, proto, service, version in open_ports:
        service_lower = service.lower()
        for keyword, note in RISKY.items():
            if keyword in service_lower:
                lines.append(f"{port}/{proto} ({service}): {note}")
                threat_found = True
    if not threat_found:
        lines.append("No high-risk services identified by service name.")
    lines.append("")

    confirmed_vulns = []
    blocks = re.split(r"\n(?=\| |\|_)", content)
    current_script = None
    for block in blocks:
        header_match = re.match(r"\|_?\s*([\w\-\.]+):", block)
        if header_match:
            current_script = header_match.group(1)
        if "State: VULNERABLE" in block:
            prior_text = block.split("State: VULNERABLE")[0]
            last_line = prior_text.strip().split("\n")[-1] if prior_text.strip() else ""
            if "LIKELY" in last_line:
                continue
            cve_matches = re.findall(r"CVE-\d{4}-\d+", block)
            title_match = re.search(r"\|\s+(.+)\n\s*\|\s+VULNERABLE", block)
            title = title_match.group(1).strip() if title_match else (current_script or "Unknown")
            cve_str = ", ".join(sorted(set(cve_matches))) if cve_matches else "No CVE listed"
            confirmed_vulns.append(f"{title} -- {cve_str}")

    lines.append("CONFIRMED VULNERABILITIES")
    lines.append("-" * 25)
    if confirmed_vulns:
        lines.extend(confirmed_vulns)
    else:
        lines.append("No confirmed (State: VULNERABLE) findings from nmap vuln scripts.")
    lines.append("")

    return lines


def run_module(out, ips_file=None, **kwargs):
    if not tool_exists("nmap"):
        warn("nmapscan: nmap not found, skipping module.")
        return

    ips_path = ips_file or out.path("ips")
    ips = read_lines(ips_path)
    if not ips:
        warn("nmapscan: no IPs found, skipping.")
        return

    ok(f"nmapscan: total IPs to scan: {len(ips)}")

    full_findings = []
    network_findings = []

    for ip in ips:
        log(f"nmapscan: scanning {ip}...")
        raw = scan_ip(ip)

        full_findings.append("=" * 64)
        full_findings.append(f"NMAP VULNERABILITY REPORT FOR: {ip}")
        full_findings.append(f"Date: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        full_findings.append("=" * 64)
        full_findings.append("")

        if not raw.strip():
            full_findings.append("[*] No open ports found (naabu pre-scan), nmap skipped.")
            full_findings.append("")
            continue

        findings = filter_vuln_output(raw)
        if findings:
            full_findings.extend(findings)
        else:
            full_findings.append("[*] No vulnerabilities detected by nmap scripts on this target.")
        full_findings.append("")

        network_findings.extend(build_network_summary(raw, ip))

    with open(out.path("nmapreport"), "a") as f:
        for line in full_findings:
            f.write(line + "\n")

    with open(out.path("network"), "a") as f:
        for line in network_findings:
            f.write(line + "\n")

    ok(f"nmapreport.txt updated, total lines this run: {len(full_findings)}")
    ok(f"network.txt updated, total lines this run: {len(network_findings)}")
