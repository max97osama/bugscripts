import re
from reconpy.core.utils import log, ok, warn, tool_exists, run, read_lines, sleep_for


def run_module(out, parameters_file=None, **kwargs):
    if not tool_exists("commix"):
        warn("commixrecon: commix not found, skipping module.")
        return

    params_path = parameters_file or out.path("parameters")
    urls = read_lines(params_path)
    if not urls:
        warn("commixrecon: no URLs found in parameters.txt, skipping.")
        return

    ok(f"commixrecon: total URLs to test: {len(urls)}")

    report_lines = []

    for url in urls:
        log(f"commixrecon: testing {url}...")
        out_text = run([
            "commix", "-u", url, "--batch", "--level=1", "--time-sec=5",
            "--skip-waf", "--no-logging",
        ], timeout=180)

        if re.search(r"is vulnerable|injectable|target url is vulnerable", out_text, re.IGNORECASE):
            report_lines.append(f"[Commix] {url}")
            for line in out_text.splitlines():
                if re.search(r"is vulnerable|injectable|technique|payload|parameter", line, re.IGNORECASE):
                    report_lines.append(line.strip())
            report_lines.append("")

        sleep_for(5)

    with open(out.path("commixreport"), "a") as f:
        for line in report_lines:
            f.write(str(line) + "\n")

    ok(f"commix report updated, findings this run: {len([l for l in report_lines if l.startswith('[Commix]')])}")
