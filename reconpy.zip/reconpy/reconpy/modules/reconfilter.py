import re
import tempfile
import os
from reconpy.core.utils import log, ok, warn, tool_exists, run, read_lines, write_lines

URL_EXTRACT_PAT = re.compile(
    r"(https?://[a-zA-Z0-9./_:@?=&%+~#-]+|www\.[a-zA-Z0-9./_:@?=&%+~#-]+"
    r"|[a-zA-Z0-9][a-zA-Z0-9._-]*\.[a-zA-Z]{2,}(?:/[a-zA-Z0-9./_:@?=&%+~#-]*)?)"
)
IMG_EXT_PAT = re.compile(
    r"\.(jpg|jpeg|png|gif|svg|ico|bmp|webp|woff|woff2|ttf|eot|pdf|mp4|mp3)$", re.IGNORECASE
)
JS_PAT = re.compile(r"\.js(\?.*)?$", re.IGNORECASE)
NON_TEXT_EXT_PAT = re.compile(
    r"\.(js|css|jpg|jpeg|png|gif|svg|ico|webp|bmp|tiff|woff|woff2|ttf|eot|json)(\?.*)?$",
    re.IGNORECASE,
)

SECRET_PATTERN = re.compile(
    r"(api[_-]?key|apikey|api[_-]?secret|secret[_-]?key|secret|password|passwd|pwd"
    r"|access[_-]?key|access[_-]?token|auth[_-]?token|authorization|bearer"
    r"|client[_-]?secret|private[_-]?key|aws_access_key_id|aws_secret_access_key"
    r"|AKIA[0-9A-Z]{16}|eyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}"
    r"|firebase|mongodb\+srv|x-api-key)",
    re.IGNORECASE,
)
STRICT_PATTERN = re.compile(
    r"(AKIA[0-9A-Z]{16}"
    r"|eyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}"
    r"|mongodb\+srv://[^\s\"']+"
    r"|(?:api[_-]?key|apikey|api[_-]?secret|secret[_-]?key|secret|access[_-]?key"
    r"|access[_-]?token|auth[_-]?token|client[_-]?secret|private[_-]?key|x-api-key)"
    r"\s*[:=]\s*[\"'][A-Za-z0-9_./+=-]{10,}[\"'])",
    re.IGNORECASE,
)
FALSE_POSITIVE_PATTERN = re.compile(
    r"(your[_-]?(api)?[_-]?key|xxxxxxxx|00000000|changeme|example\.com|placeholder"
    r"|dummy|test[_-]?key|\{\{|\$\{|<[a-zA-Z])",
    re.IGNORECASE,
)


def run_module(out, **kwargs):
    urls_path = out.path("urls")
    raw_lines = read_lines(urls_path)
    if not raw_lines:
        warn("reconfilter: urls.txt is empty, skipping.")
        return

    log("reconfilter: extracting and cleaning URLs...")
    extracted = []
    for line in raw_lines:
        for m in URL_EXTRACT_PAT.finditer(line):
            token = m.group(0)
            if token:
                extracted.append(token)

    cleaned = []
    for token in extracted:
        token = token.strip()
        if not token or token.isdigit():
            continue
        if IMG_EXT_PAT.search(token):
            continue
        if "." not in token:
            continue
        cleaned.append(token)

    unique = sorted(set(cleaned))

    if tool_exists("uro"):
        log("reconfilter: running uro for deep deduplication...")
        with tempfile.NamedTemporaryFile(mode="w", suffix=".txt", delete=False) as tmp_in:
            tmp_in.write("\n".join(unique))
            tmp_in_path = tmp_in.name
        with tempfile.NamedTemporaryFile(suffix=".txt", delete=False) as tmp_out:
            tmp_out_path = tmp_out.name

        run(["uro", "-i", tmp_in_path, "-o", tmp_out_path], timeout=120)

        result_lines = read_lines(tmp_out_path)
        if result_lines:
            unique = sorted(set(result_lines))

        os.remove(tmp_in_path)
        os.remove(tmp_out_path)
    else:
        warn("uro not found, skipping deep deduplication.")

    write_lines(urls_path, unique, append=False)
    ok(f"reconfilter: clean unique URLs in urls.txt: {len(unique)}")

    js_urls = [u for u in unique if JS_PAT.search(u)]
    param_urls = [u for u in unique if "?" in u]
    cleaned_urls = [u for u in unique if not NON_TEXT_EXT_PAT.search(u)]

    write_lines(out.path("js"), js_urls, append=False)
    write_lines(out.path("parameters"), param_urls, append=False)
    write_lines(out.path("cleaned"), cleaned_urls, append=False)

    ok(f"js.txt: {len(js_urls)}")
    ok(f"parameters.txt: {len(param_urls)}")
    ok(f"cleaned.txt: {len(cleaned_urls)}")

    if not js_urls:
        warn("reconfilter: no JS URLs to scan for secrets, skipping content scan.")
        return

    alljs_lines = []
    findings_lines = []
    jsecrets_lines = []

    log("reconfilter: downloading JS content and scanning for secrets...")
    for url in js_urls:
        content = run(["curl", "-s", "--max-time", "15", url], timeout=20)
        alljs_lines.append(content)

        for line in content.splitlines():
            if SECRET_PATTERN.search(line):
                findings_lines.append(f"URL: {url}")
                findings_lines.append(line)
                findings_lines.append("")

        for line in content.splitlines():
            if STRICT_PATTERN.search(line) and not FALSE_POSITIVE_PATTERN.search(line):
                jsecrets_lines.append(f"URL: {url}")
                jsecrets_lines.append(line)
                jsecrets_lines.append("")

    write_lines(out.path("alljs"), alljs_lines, append=False)
    write_lines(out.path("findings"), findings_lines, append=False)
    write_lines(out.path("jsecrets"), jsecrets_lines, append=False)

    ok(f"alljs.txt: {len(alljs_lines)}")
    ok(f"Findings.txt entries: {len([l for l in findings_lines if l.startswith('URL:')])}")
    ok(f"jsecrets.txt entries: {len([l for l in jsecrets_lines if l.startswith('URL:')])}")
