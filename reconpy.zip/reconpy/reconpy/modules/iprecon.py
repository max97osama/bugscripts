import re
import os
import tempfile
import ipaddress
from reconpy.core.utils import (
    log, ok, warn, tool_exists, run, read_lines, write_lines,
    append_unique, load_targets, is_private_ip, resolve_socket, sleep_for,
)

IP_REGEX = re.compile(r"\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}")


def cloudfail_available():
    return tool_exists("cloudfail")


def run_cloudfail(sub):
    """
    Runs the installed CloudFail binary in passive-only mode against a
    single subdomain. Returns a list of IPs found in its JSON output,
    or an empty list on any failure.
    """
    if not cloudfail_available():
        return []

    with tempfile.NamedTemporaryFile(suffix=".json", delete=False) as tmp:
        out_path = tmp.name

    cmd = [
        "cloudfail",
        "-t", sub,
        "--confirm-scope",
        "--passive-only",
        "--output", "json",
        "--output-file", out_path,
        "--quiet",
    ]

    api_key = os.environ.get("SECURITYTRAILS_API_KEY")
    if api_key:
        cmd += ["--securitytrails-api", api_key]

    run(cmd, timeout=90)

    ips = []
    if os.path.isfile(out_path):
        with open(out_path, "r", errors="ignore") as f:
            content = f.read()
        ips = IP_REGEX.findall(content)
        os.remove(out_path)

    return ips


def fetch_cf_ranges():
    ranges = []
    for url in ["https://www.cloudflare.com/ips-v4", "https://www.cloudflare.com/ips-v6"]:
        text = run(["curl", "-s", "--max-time", "10", url], timeout=15)
        for line in text.splitlines():
            line = line.strip()
            if not line:
                continue
            try:
                ranges.append(ipaddress.ip_network(line, strict=False))
            except ValueError:
                continue
    return ranges


def is_cloudflare(ip_str, cf_ranges):
    try:
        ip = ipaddress.ip_address(ip_str)
        return any(ip in net for net in cf_ranges)
    except ValueError:
        return False


def run_module(out, subdomains_file=None, **kwargs):
    input_path = subdomains_file or out.path("subdomains")
    subs = read_lines(input_path)
    if not subs:
        warn("iprecon: no subdomains found, skipping.")
        return

    out.touch("activesubs", "ips")
    log(f"iprecon: total subdomains to process: {len(subs)}")

    log("iprecon: fetching Cloudflare IP ranges...")
    cf_ranges = fetch_cf_ranges()

    alive = []
    if tool_exists("httpx"):
        log("iprecon: checking alive subdomains with httpx...")
        input_text = "\n".join(subs)
        out_text = run(
            ["httpx", "-t", "1", "-rate-limit", "5", "-timeout", "10", "-status-code", "-silent"],
            timeout=300, input_text=input_text,
        )
        for line in out_text.splitlines():
            m = re.match(r"^(https?://[^\s]+)", line)
            if m:
                alive.append(m.group(1).replace("https://", "").replace("http://", "").rstrip("/"))
    else:
        warn("httpx not found, treating all subdomains as candidates.")
        alive = subs

    append_unique(out.path("activesubs"), alive)
    ok(f"alive subdomains: {len(alive)}")

    raw_ip_pairs = []

    log("iprecon: resolving with python socket resolver...")
    for sub in subs:
        for ip in resolve_socket(sub):
            raw_ip_pairs.append((sub, ip))

    if tool_exists("dnsx"):
        log("iprecon: resolving with dnsx (default resolvers)...")
        input_text = "\n".join(subs)
        out_text = run(["dnsx", "-t", "1", "-rl", "5", "-a", "-resp", "-silent"], timeout=300, input_text=input_text)
        for line in out_text.splitlines():
            for ip in IP_REGEX.findall(line):
                parts = line.split()
                sub = parts[0] if parts else ""
                raw_ip_pairs.append((sub, ip))

        log("iprecon: resolving with dnsx (alternate resolvers: Quad9, OpenDNS)...")
        input_text = "\n".join(subs)
        out_text = run(
            ["dnsx", "-t", "1", "-rl", "5", "-a", "-resp", "-silent",
             "-r", "9.9.9.9,208.67.222.222"],
            timeout=300, input_text=input_text,
        )
        for line in out_text.splitlines():
            for ip in IP_REGEX.findall(line):
                parts = line.split()
                sub = parts[0] if parts else ""
                raw_ip_pairs.append((sub, ip))
    else:
        warn("dnsx not found, IP resolution will rely on Python socket resolver only.")

    log("iprecon: querying HackerTarget...")
    for sub in subs:
        out_text = run(["curl", "-s", "--max-time", "10", f"https://api.hackertarget.com/hostsearch/?q={sub}"], timeout=15)
        for ip in IP_REGEX.findall(out_text):
            raw_ip_pairs.append((sub, ip))
        sleep_for(1)

    cf_subs = set()
    non_cf_ips = set()
    for sub, ip in raw_ip_pairs:
        if is_private_ip(ip):
            continue
        if is_cloudflare(ip, cf_ranges):
            if sub:
                cf_subs.add(sub)
        else:
            non_cf_ips.add(ip)

    ok(f"Cloudflare-protected subdomains: {len(cf_subs)}")
    ok(f"Non-Cloudflare IPs found: {len(non_cf_ips)}")

    real_ips = set(non_cf_ips)
    if cf_subs:
        log("iprecon: finding real IPs behind Cloudflare...")

        if not cloudfail_available():
            warn("cloudfail not found on PATH, skipping CloudFail step.")

        for sub in cf_subs:
            log(f"iprecon: checking origin for {sub}")

            out_text = run(["curl", "-s", "--max-time", "10",
                             f"https://api.hackertarget.com/hostsearch/?q={sub}"], timeout=15)
            real_ips.update(IP_REGEX.findall(out_text))
            sleep_for(2)

            out_text = run(["curl", "-s", "--max-time", "10",
                             f"https://crt.sh/?q=%25.{sub}&output=json"], timeout=15)
            real_ips.update(IP_REGEX.findall(out_text))
            sleep_for(2)

            out_text = run(["curl", "-sk", "--max-time", "10", "-A", "Mozilla/5.0",
                             "-D", "-", "-o", "/dev/null", f"https://{sub}"], timeout=15)
            for line in out_text.splitlines():
                if re.match(r"^(x-real-ip|x-forwarded-for|x-origin-ip|x-backend-ip):", line, re.IGNORECASE):
                    real_ips.update(IP_REGEX.findall(line))
            sleep_for(2)

            if cloudfail_available():
                log(f"iprecon: running CloudFail on {sub}...")
                cloudfail_ips = run_cloudfail(sub)
                real_ips.update(cloudfail_ips)
                sleep_for(5)

    final_ips = set()
    for ip in real_ips:
        if is_private_ip(ip):
            continue
        if is_cloudflare(ip, cf_ranges):
            continue
        final_ips.add(ip)

    new_count = append_unique(out.path("ips"), final_ips)
    ok(f"new real IPs added: {new_count}")
    ok(f"total unique real IPs in ips.txt: {len(read_lines(out.path('ips')))}")
