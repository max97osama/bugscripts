import re
from reconpy.core.utils import (
    log, ok, warn, tool_exists, run, read_lines,
    load_targets, to_url, wordlist_or_none, append_unique, sleep_for,
)

URL_PAT = re.compile(r"https?://[^\s]+")


def run_module(out, domain_input, subdomains_file=None, dir_wordlist=None, depth=3, **kwargs):
    wordlist = wordlist_or_none(dir_wordlist)

    targets = set()
    subs = read_lines(subdomains_file) if subdomains_file else []
    if subs:
        for s in subs:
            targets.add(to_url(s))
    else:
        domains = load_targets(domain_input)
        for d in domains:
            targets.add(to_url(d))

    targets = sorted(targets)
    if not targets:
        warn("crawlrecon: no targets available, skipping.")
        return

    ok(f"crawlrecon: total targets: {len(targets)}")

    raw_all = []

    for target in targets:
        log(f"crawlrecon: crawling {target}...")

        if tool_exists("hakrawler"):
            log(f"crawlrecon: hakrawler on {target}...")
            out_text = run(["hakrawler", "-depth", str(depth), "-subs", "-u"], timeout=300, input_text=target + "\n")
            raw_all.extend(URL_PAT.findall(out_text))
            sleep_for(5)
        else:
            warn("hakrawler not found, skipping.")

        if tool_exists("katana"):
            log(f"crawlrecon: katana on {target}...")
            cmd = ["katana", "-u", target, "-d", str(depth), "-jc", "-w", "1",
                   "-rl", "5", "-timeout", "10", "-silent"]
            if wordlist:
                cmd += ["-wc", wordlist]
            out_text = run(cmd, timeout=300)
            raw_all.extend(URL_PAT.findall(out_text))
            sleep_for(5)
        else:
            warn("katana not found, skipping.")

        if tool_exists("gospider"):
            log(f"crawlrecon: gospider on {target}...")
            out_text = run([
                "gospider", "-s", target, "-d", str(depth), "-t", "1", "-c", "1",
                "-w", "-a", "--no-redirect", "-q",
            ], timeout=300)
            raw_all.extend(URL_PAT.findall(out_text))
            sleep_for(8)
        else:
            warn("gospider not found, skipping.")

    unique_urls = sorted(set(raw_all))
    new_curls = append_unique(out.path("curls"), unique_urls)
    new_urls = append_unique(out.path("urls"), unique_urls)

    ok(f"curls.txt new links: {new_curls}")
    ok(f"urls.txt new links: {new_urls}")
