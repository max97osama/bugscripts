import re
import json
import tempfile
import os
from datetime import datetime
from reconpy.core.utils import log, ok, warn, tool_exists, run, read_lines, sleep_for

PORT_TOOLS = {
    "21": ("FTP", "vsftpd / ProFTPD / FileZilla Server"),
    "22": ("SSH", "OpenSSH / Dropbear"),
    "23": ("Telnet", "Telnet daemon - CRITICAL: plaintext credentials"),
    "25": ("SMTP", "Postfix / Sendmail / Exim"),
    "53": ("DNS", "BIND / Unbound / PowerDNS / dnsmasq"),
    "67": ("DHCP", "ISC DHCP Server / dnsmasq"),
    "68": ("DHCP Client", "DHCP client port"),
    "69": ("TFTP", "TFTP server - unauthenticated file transfer"),
    "80": ("HTTP", "Apache / Nginx / IIS / LiteSpeed / Caddy"),
    "110": ("POP3", "Dovecot / Courier / Cyrus"),
    "139": ("NetBIOS", "Samba / Windows File Sharing"),
    "143": ("IMAP", "Dovecot / Courier / Cyrus"),
    "161": ("SNMP", "Net-SNMP - CRITICAL: leaks OS, hardware, network info"),
    "162": ("SNMP Trap", "Net-SNMP trap receiver"),
    "443": ("HTTPS", "Apache / Nginx / IIS / LiteSpeed with SSL"),
    "445": ("SMB", "Samba / Windows SMB - check for EternalBlue"),
    "465": ("SMTPS", "Postfix / Exim with SSL"),
    "587": ("SMTP Submission", "Postfix / Exim submission port"),
    "853": ("DNS over TLS", "Unbound / BIND / PowerDNS with TLS"),
    "993": ("IMAPS", "Dovecot / Courier with SSL"),
    "995": ("POP3S", "Dovecot / Courier with SSL"),
    "1433": ("MSSQL", "Microsoft SQL Server"),
    "1521": ("Oracle DB", "Oracle Database"),
    "2049": ("NFS", "NFS server - check for unauthenticated mount"),
    "2181": ("Zookeeper", "Apache Zookeeper"),
    "2375": ("Docker", "Docker daemon UNENCRYPTED - CRITICAL: full container takeover"),
    "2376": ("Docker TLS", "Docker daemon with TLS"),
    "2379": ("etcd", "etcd key-value store - Kubernetes control plane"),
    "2380": ("etcd cluster", "etcd cluster communication"),
    "3000": ("Dev Server", "Node.js / Grafana / React dev server / Gitea"),
    "3100": ("Loki", "Grafana Loki log aggregation"),
    "3306": ("MySQL", "MySQL / MariaDB"),
    "3389": ("RDP", "Windows Remote Desktop - check for BlueKeep"),
    "4243": ("Docker alt", "Docker daemon alternate port"),
    "4444": ("Metasploit / WildFly", "Metasploit listener or JBoss WildFly"),
    "4848": ("GlassFish", "GlassFish admin console"),
    "5432": ("PostgreSQL", "PostgreSQL database"),
    "5601": ("Kibana", "Kibana log visualization"),
    "5672": ("RabbitMQ", "RabbitMQ AMQP"),
    "5900": ("VNC", "VNC remote desktop - check for no-auth"),
    "5901": ("VNC display 1", "VNC remote desktop display 1"),
    "5984": ("CouchDB", "Apache CouchDB"),
    "6379": ("Redis", "Redis - CRITICAL: often unauthenticated RCE"),
    "6443": ("Kubernetes API", "Kubernetes API server"),
    "7070": ("Jira alt / RealServer", "Jira alternate or RealNetworks RealServer"),
    "7474": ("Neo4j", "Neo4j graph database browser"),
    "7990": ("Bitbucket", "Atlassian Bitbucket"),
    "8000": ("Dev HTTP", "Python Django / Flask / Twisted dev server"),
    "8008": ("HTTP alt", "HTTP alternate / Confluence"),
    "8080": ("Tomcat / Jenkins", "Apache Tomcat / Jenkins / Squid proxy / dev server"),
    "8086": ("InfluxDB", "InfluxDB time-series database"),
    "8088": ("Hadoop", "Apache Hadoop HDFS HTTP"),
    "8090": ("Confluence", "Atlassian Confluence"),
    "8443": ("Tomcat HTTPS", "Apache Tomcat HTTPS / Kubernetes API alt"),
    "8888": ("Jupyter", "Jupyter Notebook - CRITICAL: often unauthenticated RCE"),
    "9000": ("SonarQube / Portainer", "SonarQube / Portainer / PHP-FPM"),
    "9090": ("Prometheus / Cockpit", "Prometheus metrics / Cockpit web admin"),
    "9092": ("Kafka", "Apache Kafka"),
    "9100": ("Prometheus exporter", "Prometheus node exporter - leaks system metrics"),
    "9200": ("Elasticsearch", "Elasticsearch - CRITICAL: often unauthenticated data dump"),
    "9300": ("Elasticsearch cluster", "Elasticsearch cluster communication"),
    "10250": ("Kubelet API", "Kubernetes Kubelet - CRITICAL: node-level container access"),
    "10255": ("Kubelet readonly", "Kubernetes Kubelet read-only API"),
    "11211": ("Memcached", "Memcached - CRITICAL: unauthenticated data exposure + DDoS amplification"),
    "15672": ("RabbitMQ UI", "RabbitMQ management web UI"),
    "27017": ("MongoDB", "MongoDB - CRITICAL: often unauthenticated DB access"),
    "27018": ("MongoDB shard", "MongoDB shard server"),
    "50000": ("Jenkins agent", "Jenkins agent port - CRITICAL: potential RCE"),
}
CRITICAL_PORTS = {"23", "2375", "6379", "8888", "9200", "10250", "11211", "27017", "27018", "50000", "161", "2379", "4444"}

NMAP_PORTS = ",".join(sorted(PORT_TOOLS.keys(), key=int))

VERSION_PAT = re.compile(r"(v?\d+\.\d+[\.\d]*|/\d+\.\d+[\.\d]*|\d+\.\d+[\.\d]*[a-zA-Z]\w*)", re.IGNORECASE)
SKIP_PAT = re.compile(
    r"^\s*$|^Starting Nmap|^Host is up|Nmap done|^#|^SF:|latency|Not shown|^PORT\s+STATE"
    r"|Warning:|^Initiating|^Completed|^NSE:|^Scanning|^Sending|^Increasing|^Stats:|^Read data",
    re.IGNORECASE,
)
TECH_KEYWORDS = re.compile(
    r"apache|nginx|iis|litespeed|caddy|tomcat|php|python|ruby|java|node|perl|asp\.net|golang|rust"
    r"|wordpress|drupal|joomla|magento|prestashop|typo3|opencart|concrete5|ghost|october|craft|umbraco"
    r"|laravel|django|flask|rails|spring|express|symfony|codeigniter|yii|zend"
    r"|mysql|mariadb|postgresql|mssql|oracle|mongodb|redis|elasticsearch|cassandra|sqlite|couchdb|memcached|influxdb"
    r"|react|angular|vue|jquery|bootstrap|svelte|ember|backbone"
    r"|ubuntu|debian|centos|redhat|fedora|windows server|freebsd|unix"
    r"|openssl|openssh|mod_ssl|cloudflare|akamai|fastly|varnish|squid|haproxy"
    r"|docker|kubernetes|jenkins|gitlab|jira|confluence|grafana|kibana|prometheus|zookeeper|kafka|rabbitmq"
    r"|x-powered-by|server:|x-generator|x-aspnet|x-runtime|x-framework"
    r"|cpanel|plesk|directadmin|webmin|glassfish|wildfly|jetty|waf|firewall|load.balancer|cdn|cache"
    r"|plugin|theme|version|banner|product|service|open|filtered"
    r"|vulnerability|vulnerabilities|CVE-|outdated|admin|user|enumerat",
    re.IGNORECASE,
)
OPEN_PAT = re.compile(r"(\d+)/tcp\s+(open|filtered|open\|filtered)", re.IGNORECASE)
OS_PAT = re.compile(r"(OS details:|Running:|Aggressive OS guesses:|OS CPE:)\s*(.+)")
TARGET_MARKER_PAT = re.compile(r"===\s+\w[\w\s]*:\s+(\S+)\s+===")
CONFIRMED_TECH_PAT = re.compile(r"\b([A-Za-z][A-Za-z0-9_.+-]{1,30})[\[/]v?(\d+(?:\.\d+){0,3}[a-zA-Z0-9]*)\]?")

NAABU_RATE = 200
NAABU_THREADS = 25
NAABU_TIMEOUT = 180


def naabu_discover_ports(target):
    """
    Fast pre-scan across the curated port list using naabu. Returns a
    sorted list of open TCP port strings, or None if naabu is unavailable.
    """
    if not tool_exists("naabu"):
        return None

    host = target.replace("https://", "").replace("http://", "").rstrip("/")

    with tempfile.NamedTemporaryFile(suffix=".json", delete=False) as tmp:
        tmp_path = tmp.name

    run([
        "naabu", "-host", host, "-p", NMAP_PORTS,
        "-rate", str(NAABU_RATE), "-c", str(NAABU_THREADS),
        "-silent", "-json", "-o", tmp_path,
    ], timeout=NAABU_TIMEOUT)

    ports = []
    if os.path.isfile(tmp_path):
        with open(tmp_path, "r", errors="ignore") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    data = json.loads(line)
                    port = data.get("port")
                    if port:
                        ports.append(str(port))
                except (json.JSONDecodeError, ValueError):
                    continue
        os.remove(tmp_path)

    return sorted(set(ports), key=int)


def run_nmap(target):
    host = target.replace("https://", "").replace("http://", "").rstrip("/")
    ports = naabu_discover_ports(target)

    if ports is None:
        warn(f"naabu not found, falling back to nmap's own discovery for {host} (slower).")
        scan_ports = NMAP_PORTS
    elif not ports:
        ok(f"naabu found no open ports on {host} out of the curated list, skipping nmap.")
        return ""
    else:
        ok(f"naabu found {len(ports)} open port(s) on {host}: {','.join(ports)}")
        scan_ports = ",".join(ports)

    return run([
        "timeout", "600", "nmap", "-sV", "-sC", "-O", "--osscan-guess", "--max-os-tries", "1",
        "-T3", "-n", "-p", scan_ports,
        "--host-timeout", "8m", "--script-timeout", "45s",
        "--script", "banner,http-server-header,http-generator,http-title,http-auth-finder,"
                    "http-headers,ssh-hostkey,ftp-anon,ssl-cert,http-robots.txt,snmp-info,"
                    "smb-os-discovery,redis-info,mongodb-info,mysql-info,ms-sql-info",
        host,
    ], timeout=960)


def run_module(out, subdomains_file=None, ips_file=None, **kwargs):
    subs_path = subdomains_file or out.path("subdomains")
    ips_path = ips_file or out.path("ips")

    subs = read_lines(subs_path)
    ips = read_lines(ips_path)

    targets = sorted(set(subs) | set(ips))
    if not targets:
        warn("techrecon: no subdomains or IPs found, skipping.")
        return

    http_targets = []
    for t in targets:
        if re.match(r"^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$", t):
            continue
        http_targets.append(t if t.startswith("http") else f"https://{t}")

    ok(f"techrecon: total targets: {len(targets)}")

    raw_sections = []
    port_findings = {}

    if tool_exists("nmap"):
        for target in targets:
            log(f"techrecon: nmap scanning {target}...")
            out_text = run_nmap(target)
            raw_sections.append((f"=== NMAP: {target} ===", out_text))

            port_hits = []
            for port, state in OPEN_PAT.findall(out_text):
                if port in PORT_TOOLS:
                    service, tools = PORT_TOOLS[port]
                    flag = " *** CRITICAL ***" if port in CRITICAL_PORTS else ""
                    entry = f"  PORT {port} ({state.upper()}): {service} -> Possibly: {tools}{flag}"
                    if entry not in port_hits:
                        port_hits.append(entry)
            if port_hits:
                port_findings[target] = port_hits
            sleep_for(5)
    else:
        warn("nmap not found, skipping nmap steps.")

    detected_wordpress = []
    detected_other_cms = []

    for target in http_targets:
        if tool_exists("whatweb"):
            log(f"techrecon: whatweb on {target}...")
            out_text = run(["timeout", "30", "whatweb", target, "--color=never", "-a", "1"], timeout=40)
            raw_sections.append((f"=== WHATWEB: {target} ===", out_text))
            if "wordpress" in out_text.lower():
                detected_wordpress.append(target)
            sleep_for(5)
        else:
            warn("whatweb not found, skipping.")

        if tool_exists("webanalyze"):
            log(f"techrecon: webanalyze on {target}...")
            out_text = run(["timeout", "30", "webanalyze", "-host", target, "-crawl", "1"], timeout=40)
            raw_sections.append((f"=== WEBANALYZE: {target} ===", out_text))
            sleep_for(5)
        else:
            warn("webanalyze not found, skipping.")

        out_text = run(["curl", "-skI", target, "--max-time", "10", "-A", "Mozilla/5.0"], timeout=15)
        raw_sections.append((f"=== CURL HEADERS: {target} ===", out_text))
        sleep_for(3)

        if tool_exists("wafw00f"):
            log(f"techrecon: wafw00f on {target}...")
            out_text = run(["timeout", "30", "wafw00f", target], timeout=40)
            raw_sections.append((f"=== WAFW00F: {target} ===", out_text))
            sleep_for(5)
        else:
            warn("wafw00f not found, skipping.")

        if tool_exists("httpx"):
            log(f"techrecon: httpx tech-detect on {target}...")
            out_text = run(
                ["httpx", "-tech-detect", "-status-code", "-title", "-server", "-silent", "-threads", "1", "-timeout", "10"],
                timeout=30, input_text=target + "\n",
            )
            raw_sections.append((f"=== HTTPX TECH: {target} ===", out_text))
            sleep_for(5)
        else:
            warn("httpx not found, skipping.")

        if tool_exists("cmseek"):
            log(f"techrecon: cmseek on {target}...")
            out_text = run(["timeout", "60", "cmseek", "-u", target, "--follow-redirect", "-r"], timeout=70)
            raw_sections.append((f"=== CMSEEK: {target} ===", out_text))
            low = out_text.lower()
            if "wordpress" in low and target not in detected_wordpress:
                detected_wordpress.append(target)
            else:
                for cms in ["drupal", "joomla", "magento", "prestashop", "typo3", "opencart",
                            "concrete5", "ghost", "october", "craft", "umbraco", "moodle",
                            "vbulletin", "phpbb", "xenforo", "modx", "silverstripe"]:
                    if cms in low:
                        detected_other_cms.append((target, cms))
                        break
            sleep_for(5)
        else:
            warn("cmseek not found, skipping.")

    for target in detected_wordpress:
        if tool_exists("wpscan"):
            log(f"techrecon: WordPress detected on {target}, running wpscan...")
            out_text = run([
                "timeout", "300", "wpscan", "--url", target, "--no-banner", "--disable-tls-checks",
                "--throttle", "2000", "--request-timeout", "10",
                "--enumerate", "vp,vt,u,tt,cb,dbe",
            ], timeout=310)
            raw_sections.append((f"=== WPSCAN: {target} ===", out_text))
            sleep_for(10)
        else:
            warn("wpscan not found, skipping.")

    for target, cms_name in detected_other_cms:
        if tool_exists("cmsmap"):
            log(f"techrecon: {cms_name} detected on {target}, running cmsmap...")
            out_text = run(["timeout", "180", "cmsmap", target, "-t", "1"], timeout=190)
            raw_sections.append((f"=== CMSMAP ({cms_name}): {target} ===", out_text))
            sleep_for(10)
        else:
            warn("cmsmap not found, skipping.")

    tech_lines = []
    seen = set()

    if port_findings:
        tech_lines.append("=" * 60)
        tech_lines.append("PORT-BASED TOOL DETECTION")
        tech_lines.append("=" * 60)
        for target, entries in port_findings.items():
            tech_lines.append(f"\nTarget: {target}")
            tech_lines.append("-" * 40)
            tech_lines.extend(entries)

    for header, text in raw_sections:
        section_lines = []
        for line in text.splitlines():
            line_s = line.strip()
            if SKIP_PAT.search(line_s):
                continue
            if not VERSION_PAT.search(line_s) and not TECH_KEYWORDS.search(line_s):
                continue
            if line_s in seen:
                continue
            seen.add(line_s)
            section_lines.append(line_s)
        if section_lines:
            tech_lines.append(f"\n{header}")
            tech_lines.append("-" * len(header))
            tech_lines.extend(section_lines)

    with open(out.path("tech"), "a") as f:
        for line in tech_lines:
            f.write(line + "\n")

    full_content = "\n".join(f"{h}\n{t}" for h, t in raw_sections)

    os_by_target = {}
    current_target = None
    for line in full_content.splitlines():
        tmatch = re.match(r"===\s+NMAP:\s+(\S+)\s+===", line.strip())
        if tmatch:
            current_target = tmatch.group(1)
            continue
        omatch = OS_PAT.search(line)
        if omatch and current_target:
            label, value = omatch.groups()
            os_by_target.setdefault(current_target, [])
            entry = f"{label} {value.strip()}"
            if entry not in os_by_target[current_target]:
                os_by_target[current_target].append(entry)

    confirmed_by_target = {}
    current_target = None
    for line in full_content.splitlines():
        tmatch = TARGET_MARKER_PAT.match(line.strip())
        if tmatch:
            current_target = tmatch.group(1)
            continue
        if current_target is None:
            continue
        for m in CONFIRMED_TECH_PAT.finditer(line):
            name, version = m.groups()
            if name.lower() in ("http", "https", "tcp", "udp", "cve"):
                continue
            confirmed_by_target.setdefault(current_target, set())
            confirmed_by_target[current_target].add(f"{name} {version}")

    techstack_lines = []
    techstack_lines.append("=" * 64)
    techstack_lines.append("TECH STACK SUMMARY")
    techstack_lines.append(f"Date: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    techstack_lines.append("=" * 64)
    techstack_lines.append("")

    techstack_lines.append("OS DETECTION")
    techstack_lines.append("-" * 12)
    if os_by_target:
        for target, entries in os_by_target.items():
            techstack_lines.append(f"\nTarget: {target}")
            for e in entries:
                techstack_lines.append(f"  {e}")
    else:
        techstack_lines.append("No OS details confirmed by nmap on any target.")
    techstack_lines.append("")

    techstack_lines.append("CONFIRMED TOOLS/VERSIONS")
    techstack_lines.append("-" * 24)
    if confirmed_by_target:
        for target, entries in confirmed_by_target.items():
            techstack_lines.append(f"\nTarget: {target}")
            for e in sorted(entries):
                techstack_lines.append(f"  {e}")
    else:
        techstack_lines.append("No confirmed tool versions extracted.")
    techstack_lines.append("")

    techstack_lines.append("POSSIBLE (PORT-INFERRED, UNCONFIRMED)")
    techstack_lines.append("-" * 38)
    if port_findings:
        for target, entries in port_findings.items():
            techstack_lines.append(f"\nTarget: {target}")
            for entry in entries:
                techstack_lines.append(entry)
    else:
        techstack_lines.append("No port-based candidates identified.")
    techstack_lines.append("")

    with open(out.path("techstack"), "a") as f:
        for line in techstack_lines:
            f.write(line + "\n")

    ok(f"Port-based detections for {len(port_findings)} targets")
    ok(f"tech.txt total lines written this run: {len(tech_lines)}")
    ok(f"techstack.txt total lines written this run: {len(techstack_lines)}")
