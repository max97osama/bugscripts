import re
from reconpy.core.utils import (
    log, ok, warn, tool_exists, run, read_lines,
    append_unique, load_targets, sleep_for,
)

URL_PAT = re.compile(r"https?://[^\s]+")


def run_module(out, domain_input, subdomains_file=None, **kwargs):
    targets = []
    subs = read_lines(subdomains_file) if subdomains_file else []
    if subs:
        targets = subs
    else:
        targets = load_targets(domain_input)

    if not targets:
        warn("urlrecon: no targets available, skipping.")
        return

    ok(f"urlrecon: total targets: {len(targets)}")

    all_raw = []

    for target in targets:
        log(f"urlrecon: gathering URLs for {target}...")

        if tool_exists("gau"):
            out_text = run(["gau", target, "--threads", "1", "--timeout", "10", "--retries", "2"], timeout=180)
            all_raw.extend(out_text.splitlines())
            sleep_for(3)
        else:
            warn("gau not found, skipping.")

        if tool_exists("waybackurls"):
            out_text = run(["waybackurls", target], timeout=180)
            all_raw.extend(out_text.splitlines())
            sleep_for(3)
        else:
            warn("waybackurls not found, skipping.")

        if tool_exists("paramspider"):
            out_text = run(["paramspider", "-d", target, "--quiet"], timeout=180)
            all_raw.extend(URL_PAT.findall(out_text))
            sleep_for(5)
        else:
            warn("paramspider not found, skipping.")

    deduped = sorted(set(l.strip() for l in all_raw if l.strip()))

    if tool_exists("httpx") and deduped:
        log("urlrecon: validating URLs with httpx...")
        input_text = "\n".join(deduped)
        out_text = run(
            ["httpx", "-t", "1", "-rate-limit", "5", "-timeout", "10", "-silent",
             "-mc", "200,201,301,302,307,401,403"],
            timeout=600, input_text=input_text,
        )
        live = sorted(set(URL_PAT.findall(out_text)))
    else:
        warn("httpx not found, skipping live validation.")
        live = deduped

    js_urls = [u for u in live if re.search(r"\.js(\?.*)?$", u, re.IGNORECASE)]
    excluded_ext = r"\.(jpg|jpeg|png|gif|svg|ico|bmp|webp|css|json|js|woff|woff2|ttf|eot|pdf|mp4|mp3|zip|tar|gz)(\?.*)?$"
    clean_urls = [u for u in live if not re.search(excluded_ext, u, re.IGNORECASE)]
    param_urls = [u for u in clean_urls if re.search(r"\?[^=]+=|&[^=]+=", u)]

    new_urls = append_unique(out.path("urls"), clean_urls)
    new_js = append_unique(out.path("js"), js_urls)
    new_params = append_unique(out.path("parameters"), param_urls)

    ok(f"urls.txt new entries: {new_urls}")
    ok(f"js.txt new entries: {new_js}")
    ok(f"parameters.txt new entries: {new_params}")
