import re
from reconpy.core.utils import (
    log, ok, warn, tool_exists, run, read_lines, load_targets, to_url, sleep_for,
)


def run_module(out, domain_input, subdomains_file=None, **kwargs):
    if not tool_exists("smuggler"):
        warn("smugglerrecon: smuggler not found, skipping module.")
        return

    subs = read_lines(subdomains_file) if subdomains_file else []
    domains = load_targets(domain_input)

    targets = sorted(set([to_url(s) for s in subs] + [to_url(d) for d in domains]))
    if not targets:
        warn("smugglerrecon: no targets available, skipping.")
        return

    ok(f"smugglerrecon: total targets: {len(targets)}")

    report_lines = []

    for target in targets:
        log(f"smugglerrecon: testing {target}...")
        out_text = run(["smuggler", "-u", target, "--quiet", "--timeout", "10"], timeout=120)

        if re.search(r"vulnerable|issue found|CL\.TE|TE\.CL|TE\.TE", out_text, re.IGNORECASE):
            report_lines.append(f"[Smuggler] {target}")
            for line in out_text.splitlines():
                if re.search(r"vulnerable|issue found|CL\.TE|TE\.CL|TE\.TE|payload", line, re.IGNORECASE):
                    report_lines.append(line.strip())
            report_lines.append("")

        sleep_for(8)

    with open(out.path("smugglerreport"), "a") as f:
        for line in report_lines:
            f.write(str(line) + "\n")

    ok(f"smuggler report updated, findings this run: {len([l for l in report_lines if l.startswith('[Smuggler]')])}")
