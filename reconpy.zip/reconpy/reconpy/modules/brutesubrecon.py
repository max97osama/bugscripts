import re
import json
import tempfile
import os
from reconpy.core.utils import (
    log, ok, warn, tool_exists, run, read_lines, write_lines,
    append_unique, load_targets, wordlist_or_none, sleep_for,
)

FFUF_RATE = 20
FFUF_THREADS = 3
FFUF_MAXTIME_PER_DOMAIN = 1800


def run_module(out, domain_input, subdomains_file=None, subs_wordlist=None, **kwargs):
    wordlist = wordlist_or_none(subs_wordlist)
    if not wordlist:
        warn("brutesubrecon: no valid subdomains wordlist provided, skipping module.")
        return

    domains = load_targets(domain_input)
    if not domains:
        warn("brutesubrecon: no valid domain input, skipping.")
        return

    subdomains_path = subdomains_file or out.path("subdomains")
    out.touch("subdomains", "cleanedsubs")

    wordlist_lines = len(read_lines(wordlist))
    estimated_seconds = wordlist_lines // FFUF_RATE if FFUF_RATE else 0
    log(f"brutesubrecon: total domains to process: {len(domains)}")
    log(f"brutesubrecon: wordlist size: {wordlist_lines} lines")
    if estimated_seconds > FFUF_MAXTIME_PER_DOMAIN:
        warn(f"wordlist would take ~{estimated_seconds // 60} minutes per domain at current rate; "
             f"capping each domain's ffuf run to {FFUF_MAXTIME_PER_DOMAIN // 60} minutes.")

    all_candidates = set(read_lines(subdomains_path))
    domain_pattern = re.compile(
        r"^[a-zA-Z0-9]([a-zA-Z0-9\-]{0,61}[a-zA-Z0-9])?(\.[a-zA-Z0-9]([a-zA-Z0-9\-]{0,61}[a-zA-Z0-9])?)*$"
    )

    for domain in domains:
        log(f"brutesubrecon: starting bruteforce for {domain}")

        ffuf_hosts = []
        if tool_exists("ffuf"):
            log(f"brutesubrecon: ffuf on {domain} (rate={FFUF_RATE}, threads={FFUF_THREADS}, "
                f"maxtime={FFUF_MAXTIME_PER_DOMAIN}s)...")
            with tempfile.NamedTemporaryFile(suffix=".json", delete=False) as tmp:
                tmp_path = tmp.name
            run([
                "ffuf", "-u", f"https://FUZZ.{domain}",
                "-w", wordlist,
                "-t", str(FFUF_THREADS),
                "-rate", str(FFUF_RATE),
                "-timeout", "5",
                "-maxtime", str(FFUF_MAXTIME_PER_DOMAIN),
                "-se",
                "-mc", "200,301,302,403",
                "-o", tmp_path, "-of", "json", "-s",
            ], timeout=FFUF_MAXTIME_PER_DOMAIN + 60)
            if os.path.isfile(tmp_path):
                try:
                    with open(tmp_path) as f:
                        data = json.load(f)
                    for r in data.get("results", []):
                        host = r.get("input", {}).get("FUZZ", "")
                        if host:
                            ffuf_hosts.append(f"{host}.{domain}")
                except Exception:
                    pass
                os.remove(tmp_path)
            else:
                warn(f"ffuf produced no output for {domain} (timed out or found nothing).")
            sleep_for(3)
        else:
            warn("ffuf not found, skipping ffuf step.")

        knock_hosts = []
        if tool_exists("knockpy"):
            log(f"brutesubrecon: knockpy on {domain}...")
            out_text = run(["knockpy", domain, "--recon", "--no-http"], timeout=300)
            knock_hosts = re.findall(rf"[a-zA-Z0-9._-]+\.{re.escape(domain)}", out_text)
            sleep_for(3)
        else:
            warn("knockpy not found, skipping.")

        alterx_hosts = []
        if tool_exists("alterx"):
            domain_subs = [s for s in all_candidates if domain in s]
            if domain_subs:
                log(f"brutesubrecon: alterx permutation on {domain}...")
                input_text = "\n".join(domain_subs)
                out_text = run(["alterx", "-enrich"], timeout=120, input_text=input_text)
                alterx_hosts = [l.strip() for l in out_text.splitlines() if l.strip()]
        else:
            warn("alterx not found, skipping.")

        for host in ffuf_hosts + knock_hosts + alterx_hosts:
            host = host.strip().lower()
            if host and domain_pattern.match(host) and domain in host:
                all_candidates.add(host)

    new_candidates = sorted(all_candidates - set(read_lines(subdomains_path)))
    ok(f"brutesubrecon: total unique candidates across all domains: {len(all_candidates)}")

    new_subs = append_unique(subdomains_path, new_candidates)
    append_unique(out.path("cleanedsubs"), new_candidates)

    ok(f"{new_subs} new subdomains added to {subdomains_path}")
    ok("brutesubrecon does not resolve/probe here — run iprecon next to resolve IPs and check alive status.")
