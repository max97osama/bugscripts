import re
from reconpy.core.utils import log, ok, warn, tool_exists, run, read_lines, sleep_for


def run_module(out, parameters_file=None, **kwargs):
    params_path = parameters_file or out.path("parameters")
    urls = read_lines(params_path)
    if not urls:
        warn("sqlrecon: no URLs found in parameters.txt, skipping.")
        return

    ok(f"sqlrecon: total URLs to test: {len(urls)}")

    report_lines = []

    for url in urls:
        log(f"sqlrecon: testing {url}...")

        if tool_exists("sqlmap"):
            out_text = run([
                "sqlmap", "-u", url, "--batch", "--random-agent", "--level=2", "--risk=1",
            ], timeout=300)
            if "sqlmap identified the following injection point" in out_text:
                report_lines.append(f"URL: {url}")
                report_lines.append("Vulnerability: SQL Injection")
                for line in out_text.splitlines():
                    if re.search(r"Parameter:|Type:|Title:|Payload:", line, re.IGNORECASE):
                        report_lines.append(line.strip())
                report_lines.append(
                    f'Exploit: sqlmap -u "{url}" --batch --dump '
                    f"(or --os-shell if stacked queries are supported)"
                )
                report_lines.append("")
            sleep_for(5)
        else:
            warn("sqlmap not found, skipping sqlmap step.")

    if tool_exists("crlfuzz"):
        log("sqlrecon: running crlfuzz against parameters.txt...")
        crlf_out = run(["crlfuzz", "-l", params_path, "-s"], timeout=300)
        if crlf_out.strip():
            for curl_url in crlf_out.splitlines():
                curl_url = curl_url.strip()
                if not curl_url:
                    continue
                report_lines.append(f"URL: {curl_url}")
                report_lines.append("Vulnerability: CRLF Injection")
                report_lines.append(
                    "Exploit: Inject %0d%0a sequences into the parameter to split HTTP headers "
                    "and response, enabling header injection, cache poisoning, or reflected XSS "
                    "via Set-Cookie or Location headers"
                )
                report_lines.append("")
    else:
        warn("crlfuzz not found, skipping.")

    with open(out.path("sqlreport"), "a") as f:
        for line in report_lines:
            f.write(str(line) + "\n")

    ok(f"sqlreport.txt updated, findings this run: {len([l for l in report_lines if l.startswith('URL:')])}")
